# ELEC-VQA sample

Eight reference examples from original DWG windows, selected for the research project page. This is a qualitative sample, not an evaluation split. Original relative image paths and stable QA IDs are retained. The full dataset comprises 10,201 QA records and 1,019 image configurations. References are graph-checked, not independently expert-validated.
