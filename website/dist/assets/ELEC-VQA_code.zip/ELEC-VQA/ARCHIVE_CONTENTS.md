# Code-only archive

This download contains the project code and configuration, not the full dataset, recorded results, model weights or manuscript. Obtain the complete release from https://github.com/Talulah81920/ELEC-VQA before running commands that require dataset/ or results/.
